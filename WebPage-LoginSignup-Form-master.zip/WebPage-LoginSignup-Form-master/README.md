# WEB-Login-Signup-Form
Did not attach javascript file.Available only Design pack.(Using HTML,CSS) 

- **Sign in form**

![img_1](https://user-images.githubusercontent.com/46102435/67423893-af183200-f5f2-11e9-9a54-d8f761fe33d0.PNG)

- **Sign up form (Details)**

![img_2](https://user-images.githubusercontent.com/46102435/67423960-d969ef80-f5f2-11e9-9ed3-03e6153bf47a.PNG)

- **Sign up form (Qualifications)**

![img_3](https://user-images.githubusercontent.com/46102435/67424045-03231680-f5f3-11e9-895c-8531bfdd536e.PNG)

- **Sign up form (Account Config)**

![img_4](https://user-images.githubusercontent.com/46102435/67424066-0e764200-f5f3-11e9-8653-74226c563b55.PNG)

- Design by : P M A T Anjana Bandara (NSBM Student)
